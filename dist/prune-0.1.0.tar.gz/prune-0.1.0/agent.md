This repository contains the prune CLI.
